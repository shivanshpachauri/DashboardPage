Created a react app

1 Created a react app using the command = create-react-app dashboard
2 Created three components = Top component,Middle component,bottom component
3 Installed necessay node modules such as react-bootstrap,react-router dom,mui,mui material.
4 The top component consist of the navbar and the neccessary references available. I also included a Form tag inside the top component.
5 The real logic of the react works inside the middle component.
6 Created a Data.json to include some categories and subcategories including widgets and subwidgets
7 Used a map function that receives a callback function to map the data from json to the h6 tag.
8 Used object.entries to map the subcategories(widgets) of data.json to card.
9 Object.entries converts the file format to neccessary object form
10 Created a button tag to add a widget
11 Create a state called isinput that would conditionally render a component when the button is pressed
12 Created a iconbutton from mui iconmaterial
13 Created a drawer from mui
14 Created a box
15 Mapped the data from json file to render the data into a h6 category format
16 I also added a checkbox
To run the project npm install mui material mui material icons,react bootstrap
Created by Shivansh pachauri
